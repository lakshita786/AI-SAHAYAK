# 🌾 SahayakAI - AI Livelihood Assistant for Rural India

<div align="center">

[![GitHub Stars](https://img.shields.io/github/stars/Akkii88/SahayakAI?style=flat-square)](https://github.com/Akkii88/SahayakAI/stargazers)
[![License](https://img.shields.io/github/license/Akkii88/SahayakAI?style=flat-square)](LICENSE)

**AI-powered assistant helping rural workers in India discover government schemes, jobs, and training in Hindi/English**

</div>

---

## ✨ Features

- 🤖 **AI Chat** - Conversational AI with voice input support (Hindi & English)
- 📋 **Scheme Database** - 49+ government welfare schemes
- ✅ **Eligibility Checker** - Check which schemes you qualify for
- 🌙 **Dark Mode** - Easy on the eyes, toggle in header
- 🔖 **Bookmarks** - Save schemes for later
- 📤 **Share** - Share schemes via WhatsApp
- 📱 **Mobile-Friendly** - Bottom navigation for mobile
- 🎨 **Beautiful UI** - Glassmorphism design with smooth animations

---

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- Git

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/Akkii88/SahayakAI.git
cd SahayakAI

# 2. Create virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

### Setup Environment Variables

```bash
# Create .env file and add your Groq API key
cp .env.example .env
# Edit .env and add: GROQ_API_KEY=your_api_key_here
```

**Get FREE API Key:**
1. Go to [groq.com](https://groq.com)
2. Sign up for free account
3. Copy your API key from dashboard

### Run the App

```bash
# Start the server
python app.py
```

The app will be running at: **http://localhost:8000**

---

## 📱 Pages

| Page | URL | Description |
|------|-----|-------------|
| Home | `/` | AI Chat with voice input |
| Eligibility | `/eligibility` | Check scheme eligibility |
| Schemes | `/schemes` | Browse all 49+ schemes |
| Support | `/support` | Help & FAQ |
| About | `/about` | Project information |

---

## 🛠️ Tech Stack

- **Backend:** Python, FastAPI
- **AI:** Groq LLM (Mixtral-8x7b)
- **Frontend:** HTML, Tailwind CSS, Vanilla JS
- **Database:** CSV-based scheme database
- **TTS:** Microsoft Edge TTS (free, high-quality Hindi voice)

---

## 📂 Project Structure

```
SahayakAI/
├── app.py                 # FastAPI server
├── backend/
│   ├── agent.py          # AI agent with Hindi prompt
│   ├── automl_model.py   # Eligibility logic
│   ├── nlp_classifier.py # Intent classification
│   ├── schemes_db.py    # Scheme database
│   └── speech_api.py    # Text-to-Speech API
├── UI/                    # Frontend pages
│   ├── ai_sahayak_home_screen/
│   ├── check_eligibility_form/
│   ├── scheme_recommendations/
│   ├── support/
│   └── about/
└── requirements.txt
```

---

## 🤝 Contributing

Contributions welcome! Please read the [contributing guidelines](CONTRIBUTING.md) first.

---

## 📄 License

MIT License - feel free to use this for educational purposes!

---

## 🙏 Acknowledgments

- Government of India scheme data
- Groq for free AI API
- Microsoft Edge TTS for Hindi voice

---

<div align="center">

**Made with ❤️ for rural India**

</div>